var _thebritican$elm_autocomplete$Native_Tricks = function() {

return {
    trickyMap: function(x) { return x; }
};

}();
